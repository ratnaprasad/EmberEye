EmberEye Model Export

Model Version: v20260219_183743
Exported: 2026-02-19 19:11

Installation for EmberEye Field:

1. Extract this ZIP file
2. Copy best.pt to: D:\\EE\\EmberEye\\embereye-field\\models\\
3. Copy master_classes.json to: D:\\EE\\EmberEye\\embereye-field\\
4. Restart EmberEye Field
5. Select model from dropdown

Files included:
- best.pt: Trained model (ready to use)
- master_classes.json: Class definitions
- metadata.json: Model information
- README.md: This file
