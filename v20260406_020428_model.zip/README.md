# EmberEye Model Export

Model Version: v20260406_020428
Exported: 2026-04-06 05:45:44

## Installation Instructions

### For EmberEye Field App:

1. Extract this ZIP file
2. Locate EmberEye Field application directory:
   - Default: `D:\EE\EmberEye\embereye-field\`
3. Copy `best.pt` to the models directory
4. Copy `master_classes.json` to the main application directory (replace existing if different)
5. Restart EmberEye Field application
6. The model will appear in the model selection dropdown

## Files Included

- `best.pt`: Trained YOLOv8 model weights (ready to use)
- `master_classes.json`: Class definitions (fire, smoke, structural, human, vehicle, safety, environment)
- `metadata.json`: Model information and compatibility details
- `README.md`: This installation guide

## Compatibility

✓ EmberEye Field (Desktop)
✓ EmberEye Studio
✓ YOLOv8 Framework

## Important Notes

- **Class Definitions**: This export includes `master_classes.json` which contains the class hierarchy this model was trained with. For proper detection labeling, ensure these classes are used with this model.
- **Backup**: Consider backing up your existing `master_classes.json` before updating, in case you need to revert.

## Contact

For issues or questions, refer to the main EmberEye documentation.
